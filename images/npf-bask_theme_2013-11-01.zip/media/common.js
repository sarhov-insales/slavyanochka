/* карточка товара выбор модификаций */



$(function(){

  $('.selector-wrapper li').live('click', function(){
    $(this).parents('ul:first').find('li').removeClass('active').removeAttr('selected');
    $(this).addClass('active').attr('selected','selected').trigger('change');
    $(this).parents('ul:first').trigger('change');

    
  });
});


InSales.OptionSelectors = function(existingSelectorId, options) {
    if ($("#"+existingSelectorId).attr("id") == undefined) return false

    // insert new multi-selectors and hide original selector
    this.replaceSelector = function(domId) {
        var oldSelector = document.getElementById(domId);
        var parent = oldSelector.parentNode;
        jQuery.each(this.buildSelectors(), function(index,el) {
            parent.insertBefore(el, oldSelector);
        });
        oldSelector.style.display = 'none';
        this.variantIdField = oldSelector;
    };

    // buildSelectors(index)
    // create and return new selector element for given option
    this.buildSelectors = function() {
        // build selectors
        for (var i = 0; i < this.product.optionNames().length; i++) {
            var sel = new InSales.SingleOptionSelector(this, i, this.product.optionNames()[i], this.product.optionValues(i));
            sel.element.disabled = false;
            this.selectors.push(sel);
        }

        // replace existing selector with new selectors, new hidden input field, new hidden messageElement
        var divClass = this.selectorDivClass;
        var optionNames = this.product.optionNames();
        var elements = [];
        jQuery.each(this.selectors, function(index,selector) {
            var div = document.createElement('div');
            div.setAttribute('class', divClass);
            // create label if more than 1 option (ie: more than one drop down)
            if (optionNames.length > 1 || optionNames[0].title != 'Модификация') {
                // create and appened a label into div
                var label = document.createElement('label');
                label.innerHTML = selector.name;
                div.appendChild(label);
            }
            div.appendChild(selector.element);
            elements.push(div);
        });
        return elements;
    };

     // returns array of currently selected values from all multiselectors
      this.selectedValues = function () {
        var currValues = {};       
        for (var i = 0; i < this.selectors.length; i++) {        
          var selector = this.selectors[i];
          var thisValue = $(this.selectors[i].element).find('li[selected="selected"]').attr('value');                  
          currValues[selector.option_id] = thisValue;         
        }      
        return currValues;       
      };

    this.getCurrVariant = function() {
        var currValues = this.selectedValues(); // get current values        
        return this.product.getVariant(currValues);    
    };

    // callback when a selector is updated.
    this.updateSelectors = function(index) {
        var variant    = this.getCurrVariant();
        if (variant) {
            this.variantIdField.disabled = false;
            this.variantIdField.value = variant.id; // update hidden selector with new variant id
        } else {
            this.variantIdField.disabled = true;
        }
        this.onVariantSelected(variant, this);  // callback
    };

    this.selectAvailableVariant = function() {
        var values = {};
        for (var i = 0; i < this.product.variants.length; i++) {
            var variant = this.product.variants[i];
            if (!variant.available) continue;
            jQuery.each(variant.option_values, function(index,option_value) {
                values[option_value.option_name_id] = option_value.id;
            });
            break;
        }
        jQuery.each(this.selectors, function(index,selector) {
            selector.selectValue(values[selector.option_id]);
        });
        this.selectors[0].element.onchange();     // init the new dropdown
    };
   
 
      this.filterOptionValues = function(){
        // Создаём массив значений св-в каждой модификации
        var variants_option_values = [];
        for (var i = 0; i < this.product.variants.length; i++) {
            var variant = this.product.variants[i];
            //if (!variant.available) continue;
            var variant_option_values = []
            jQuery.each(variant.option_values, function(index,option_value) {
                variant_option_values.push(option_value);
            });
            variants_option_values.push(variant_option_values)
        }

        var id_prefix = 'variant-select-option-';
        var max_option_name_index = jQuery('.single-option-selector').size() - 1;
        // При выборе значения св-ва у следующего св-ва оставляем только те значения, которые могут быть у товара при выбранных предыдущих значениях
        jQuery('.single-option-selector').live('change',function(){
        
            var selected_option_value_id = $(this).find('li[selected="selected"]').attr('value');
            var id = jQuery(this).attr('id');
            var option_name_index = parseInt(id.replace(id_prefix,''));
            if (option_name_index == max_option_name_index) return;
            var next_option_name_index = option_name_index + 1;
            var option_values = [];
            jQuery.each(variants_option_values, function(index,variant_option_values){
                var current_option_value = variant_option_values[option_name_index];
                if (current_option_value.id == selected_option_value_id) {
                    var allowed_option_value = true
                    // проходимся по ранее выбранным значениям св-в
                    for (var i=option_name_index; i >= 0; i--){
                        var prev_current_option_value_id = jQuery("#"+id_prefix+i).find('li[selected="selected"]').attr('value');
                        if (variant_option_values[i].id != prev_current_option_value_id) allowed_option_value = false;
                    }
                    if (allowed_option_value){
                        var next_option_value = variant_option_values[next_option_name_index];
                        option_values = jQuery.grep(option_values, function (option_value) {return option_value.id != next_option_value.id;});
                        option_values.push(next_option_value);
                    }
                }
            });

            var next_option_values_select = jQuery("#"+id_prefix+next_option_name_index);
            var next_selected_option_value_id = next_option_values_select.find('li[selected="selected"]').attr('value');
            var lis = "";
            jQuery.each(option_values, function(i){
                var selected = "";
                if (this.id == next_selected_option_value_id) selected = "selected='selected'";
              if (i == 0) {
                lis += "<li class='active' selected='selected' value='"+this.id+"'>"+this.title+"</li>";
              } else {
                lis += "<li value='"+this.id+"' "+ selected +" >"+this.title+"</li>";
              }
               
            });
            next_option_values_select.html(lis);
            next_option_values_select.trigger('change');
        });

        $("#"+id_prefix+0).trigger('change');
    }              

    this.selectorDivClass       = 'selector-wrapper';
    this.selectorClass          = 'single-option-selector';
    this.variantIdFieldIdSuffix = '-variant-id';

    this.variantIdField    = null;
    this.selectors         = [];
    this.domIdPrefix       = existingSelectorId;
    this.product           = new InSales.Product(options['product']);
    this.onVariantSelected = InSales.isDefined(options.onVariantSelected) ? options.onVariantSelected : function(){};
    this.replaceSelector(existingSelectorId); // create the dropdowns
    this.selectAvailableVariant();
    if (options['filterOptionValues']) this.filterOptionValues(); // Поочерёдная фильтрация значения св-в.

    return true;

};




InSales.SingleOptionSelector = function(multiSelector, index, option, values) { 
    this.selectValue = function(value) {
        $(this.element).find('li[value="'+value+'"]').each(function(){
            $(this).attr("selected","selected");
            $(this).addClass('active');
        });
    };

    this.multiSelector = multiSelector;
    this.values = values;
    this.index = index;
    this.name = option['title'];
    this.option_id = option['id'];  
    this.element = document.createElement('ul');
    for (var i = 0; i < values.length; i++) {
        var opt = document.createElement('li');
        opt.value = values[i].id;
        opt.innerHTML = values[i].title;       
        this.element.appendChild(opt);
     
    }
    this.element.setAttribute('class', this.multiSelector.selectorClass);
    this.element.id = multiSelector.domIdPrefix + '-option-' + index;
    this.element.onchange = function() {
        multiSelector.updateSelectors(index);
    };

    return true;
};

