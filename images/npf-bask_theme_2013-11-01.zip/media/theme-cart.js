// TM44552 v1
// Ruslan B. (12.07.2013)
// r.beygulenko@gmail.com
// InSales Rus LLC

	function initAjaxAddToCartButton(handle, onAddToCart) {    
		$(handle).click(function( ){
			var $element = $(this).parents('.item:first').find('.target-img');
			var $picture = $element.clone();
			var elemWidth = $element.width();
			var elemHeight = $element.height();
			var pictureOffsetOriginal = $element.offset();
			if ($picture.size())
			$picture.css({'position': 'absolute', 'top': pictureOffsetOriginal.top, 'left': pictureOffsetOriginal.left});
			$picture.css({'z-index':'10000','width': elemWidth + 'px', 'height':elemHeight + 'px'});
			var pictureOffset = $picture.offset();
			var cartBlockOffset = $('.cart').offset()		  
			if (cartBlockOffset != undefined && $picture.size()){
				$picture.appendTo('body');
				$picture.css({ 'position': 'absolute', 'top': $picture.css('top'), 'left': $picture.css('left') }).animate({ 'width': elemWidth/3, 'height': elemHeight/3, 'opacity': 0.2, 'top': cartBlockOffset.top, 'left': cartBlockOffset.left }, 800).fadeOut(800);
			}  
			$('.addtocart_window').fadeIn();
			$('.addtocart_preloader_layer').fadeIn('fast');
			addOrderItem( jQuery(this).parents("form:first"), onAddToCart);
   		});
    }

	function addOrderItem(form, onAddToCart) {
		var fields = form.serialize();
		var action = form.attr("action").split("?");
		var url = action[0] + ".json";
		var lang = action[1] ? "?"+action[1] : "";
		var path = url + lang;    
		jQuery.ajax({
			url: path,
			type: 'post',
			data: fields,
			dataType: 'json',
			success: onAddToCart,
			error: hide_preloader
		});
	}
	
$(function() {
	$('.close_popup').click(function(){$('.addtocart_window').fadeOut('fast');$('.addtocart_preloader_layer').fadeOut(); return false;});
	new InSales.Cart({
		selector: '.buy',
		draw: function(cart){
			var count_name = 'товар';
			if (cart.items_count == 2 || cart.items_count == 3 || cart.items_count == 4) {count_name = 'товара';} else if (cart.items_count > 4) { count_name = 'товаров'; }  
			
			var cart_preview = '';
			var cart_items = '';
			
		 	if(cart.items_count > 0){
				cart_preview += '<div class="total_products"><span class="cart_num"><a href="/cart_items/">'+cart.items_count+' '+count_name+'</a></span></div>';
			
				cart_items += '<div class="text-cart"> Товары в корзине </div>';
				cart_items += '<div class="vm_cart_products" id="vm_cart_products"><div class="container">';
					$(cart.order_lines).each(function(index,order_line) {
					  cart_items += '<div class="wrapper marg-bot sp"><div class="spinner"></div>';
					  cart_items += '<div class="image"> <img src="'+order_line.image('thumb')+'"> </div>';
					  cart_items += '<div class="fleft"><div class="product_row"> <span class="product_name"><a href="/product/?product_id='+order_line.product_id+'">'+order_line.title+'</a></span>';
					  cart_items += '<div class="clear"></div><span class="quantity">'+order_line.quantity+'&nbsp;x&nbsp;</span>';
					  cart_items += '<div class="prices" style="display:inline;">'+InSales.formatMoney(order_line.sale_price, cv_currency_format)+'</div><a href="javascript:;" class="vmicon vmicon vm2-remove_from_cart" id="delete_'+order_line.variant_id+'" title="Удалить с корзины">&nbsp;</a></div></div></div>';
					});  
				cart_items += '</div></div><div class="total"><div class="total2"><span>Всего:</span><strong>'+InSales.formatMoney(cart.total_price, cv_currency_format)+'</strong></div></div><div class="show_cart"> <a style="float:right;" href="/cart_items/">Перейти в корзину</a> </div>';

				$("#cart_list").html(cart_items)	
			}else{
				cart_preview += '<div class="total_products"><span class="cart_num"> пусто</span></div>';
				$('#cart_list').html('<div class="text-cart">В корзине пока пусто</div>');
			}

			$('#vmCartModule .minicart').html(cart_preview);
 
			//$('.cart-count').html(cart.items_count);
			//$('.total-price').html(InSales.formatMoney(cart.total_price, cv_currency_format));
		}
	});
});
	
	
 function checkout(){
    var qSwaps = [];
    $(".cart_row input.qty").each(function(i) {
		qSwaps[i] = $(this).val();
        if ( $(this).attr('processed') ) { return; }
        $(this).attr('processed',true);
        $(this).bind("change keyup", function(e) {
            var el = $(this);
            var value = el.val();
            val = value.replace(/[^\d\.\,]+/g,'');
            if (val < 0){}
            if(val != value) el.val(val);
            if (val == qSwaps[i]) return;
            qSwaps[i] = val;
            el.parents(".cart_row:first").find(".item-total").html( InSales.formatMoney(val*el.attr('price'), cv_currency_format) )
            recalculate_order();
        }).bind('blur',function(){
            var el = $(this);
            var value = el.val();
            val = value.replace(/[^\d\.\,]+/g,'');
            if (val < 0 || val == ""){ val = 0; }
            el.val(val);
            el.change();
        });
    });

    function recalculate_order() {
    	var fields =  new Object;
    	fields = $('#cartform').serialize();
      	var path = '/cart_items/update_all.json'
    	show_preloader();
		$.ajax({
			url:      path,
			type:     'post',
			data:     fields,
			dataType: 'json',
			success:  function(response) {
				hide_preloader();
				var count_name = 'товар';
				if (response.items_count == 2 || response.items_count == 3 || response.items_count == 4) {count_name = 'товара';} else if (response.items_count > 4) { count_name = 'товаров'; }
				if(response.discount_description){
					$.each(response.discounts, function(){
						var item = this;
						var description = item.description
						var price = InSales.formatMoney(item.amount, cv_currency_format)
						$('.discounts-list').html('<td colspan="3" align="right">'+description+':</td><td colspan="2" align="center"><strong><span class="PricebillTotal discount-summary">&minus; '+price+'</span></strong></td>')	
					})  
					$('.discounts-list').slideDown(); 
				  }else{$('.discounts-list').slideUp().html('');
				}
				$('.minicart').html('<div class="total_products"><span class="cart_num"><a href="/cart_items/">'+response.items_count+' '+count_name+'</a></span></div>');
				$('.cart-summary-t').html(InSales.formatMoney(response.total_price, cv_currency_format));
				},
			error:  function(response) {  alert("произошла ошибка"); hide_preloader(); }
		});
    }
}