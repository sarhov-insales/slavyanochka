// TM44552 v1
// Ruslan B. (12.07.2013)
// r.beygulenko@gmail.com
// InSales Rus LLC

// antihack for comments
function check(e){var t;var n;var r;if(window.event){t=e.keyCode}else if(e.which){t=e.which}n=String.fromCharCode(t);if(n=="'"||n=="`"||n=="!"||n=="#"||n=="$"||n=="%"||n=="^"||n=="&"||n=="*"||n=="("||n==")"||n=="-"||n=="_"||n=="+"||n=="="||n=="/"||n=="~"||n=="<"||n==">"||n==","||n==";"||n==":"||n=="|"||n=="?"||n=="{"||n=="}"||n=="["||n=="]"||n=="¬"||n=="£"||n=='"'||n=="\\"){return false}else{return true}}
// save product
function saveProduct2(e){if($.cookie("product_ids")!=null){var t=$.cookie("product_ids").split(",");for(var n=0;n<t.length;n++){if(t[n]==e){return}}if(t.length>=10){t.shift()}t.push(e);$.cookie("product_ids",t,{path:"/"})}else{$.cookie("product_ids",e,{path:"/"})}}
	
$(function(){
	
	// recently viewed
	if($.cookie('product_ids') != null) {
      $.getJSON("/products_by_id/"+$.cookie('product_ids')+".json",
        function(data){
          var products = '';
           $.each(data.products, function(i,product){
		   		$('.recentproducts').append('<li><img src="'+product.images[0].url+'" class="image"><a href="/product/?product_id='+product.id+'" title="'+product.title+'">'+product.title+'</a></li>') 
           });  
			$('.recentproducts').show(); 
        });
    }
	
	// validate search field
	$('#searchbox input[type=text]').bind('change keyup', function(){$(this).parent().removeClass('search-error')})
	$('#searchbox input[type=submit]').click(function(){if($('#searchbox input[type=text]').val() == 'Поисковый запрос' ){$(this).parent().addClass('search-error'); return false}else{$('#searchbox').submit(); return false;}});
	// change view
	var cc=$.cookie("list_grid");if(cc=="g"){$(".changeview").addClass("grid");$(".changeview").removeClass("list");$(".Clist").removeClass("active");$(".Cgrid").addClass("active")}else{$(".changeview").removeClass("grid");$(".changeview").addClass("list");$(".Clist").addClass("active");$(".Cgrid").removeClass("active")}$(".Cgrid").click(function(){$(".changeview").fadeOut(300,function(){$(this).addClass("grid").removeClass("list").fadeIn(300)});$(".Clist").removeClass("active");$(".Cgrid").addClass("active");$.cookie("list_grid","g",{path:"/"});return false});$(".Clist").click(function(){$(".changeview").fadeOut(300,function(){$(this).removeClass("grid").addClass("list").fadeIn(300)});$(".Clist").addClass("active");$(".Cgrid").removeClass("active");$.cookie("list_grid","l",{path:"/"});return false})
	// cart open
	$('#vmCartModule').hover( function(){$('#cart_list').stop(true,true).slideDown(400)}, function(){$('#cart_list').stop(true,true).delay(500).slideUp(100)})
	// quantity plus-minus
	$(".product-qty").each(function(){var e=$(this).find("input[type=text]");var t=$(this).find(".quantity-plus");var n=$(this).find(".quantity-minus");t.click(function(){var t=e.val();t=++t;e.val(t);return false});n.click(function(){var t=e.val();t=--t;if(t==0){return false}else{e.val(t)}return false})});	
	// protect
	$('.protect').bind('cut copy paste contextmenu dragstart', function(e){e.preventDefault();});
	// only numbers
	$(".num").numeric().keyup(function(e){var t=$(this).val();while(t.substring(0,1)==="0"){t=t.substring(1)}$(this).val(t)})
	// main navigation (superfish)
	$('.list li.has-children ').hover(function() {$(this).find('ul:first').stop(true, true).fadeIn("slow"); },function() {$(this).find('ul:first').stop(true, true).delay(100).fadeOut("slow");});
	// user auth
	$.getJSON("/client_account/contacts.json",function(data){if(data.status != "error"){$('.poping_links').html('Вы вошли как <a href="/client_account/contacts" id="user-logged">'+data.client.name+'</a>, (<a href="/client_account/exit">Выйти</a>)');}else{$('.poping_links').html('<a href="/client_account/session/new" id="openReg">Войти</a>&nbsp;&nbsp;&nbsp;или&nbsp; <a href="/client_account/contacts/new">Зарегистрироваться</a>');}});
	
	// add to compare
	$("a.add_to_compare").click(function(e){ e.preventDefault() });
	new InSales.Compare({
		selector: 'a.add_to_compare',
		draw: function(products) {
			var text = '';
			text += '<div class="module_new block-static random"><h3><span><span>Сравнить</span></span></h3><div class="boxIndent"><div class="wrapper2"> <div class="vmgroup_new"><div class="block-c">';
			if (products.length == 0) {
				text += '<div class="noforcompare">Нет товаров для сравнения</div>';
				$('#compare_div').html('<p>Товары для сравнения не выбраны</p><p><a href="/"  class="button" title="На главную">На главную</a></p>');
			} else {
				$(products).each(function(index,product) {
					text += '<div class="compare-item clrf">';
					text += '<a class="prod-name" href="/product/?product_id='+product.id+'" title="'+product.title+'">'+product.title+'</a>';
					text += '<a class="ajax_cart_block_remove_link remove_compare prod-remove" href="javascript:;" rel="'+product.id+'">&nbsp;</a></div>';
				});
				text += '<a href="/compares" class="button">Cравнить выбранное</a>';
			}
			text += '</div></div></div></div></div>';
			$('#compare').html(text);	 
		}
     });
	
 
	

 	// compare page table
    $('#compare_table').fixedtableheader();
 	$(".compare_show_similar").hide();
    $('#compare_table thead tr:first th').each(function(){ $(".product_cell_main",this).width($(this).width()); });
    if(!$("#compare_table .same").length){ $(".compare_show_similar, .compare_hide_similar").hide(); } else { $(".compare_show_similar").live("click",function(){ $(".compare_show_similar").hide(); $(".compare_hide_similar").show(); $("#compare_table .same").show(); });
        $(".compare_hide_similar").live("click",function(){ $(".compare_hide_similar").hide(); $(".compare_show_similar").show(); $("#compare_table .same").hide();});
    }
	

	// product tabs
	 var page = $('body,html');
		  var tab_group = $('.tabs-wrap > .responsive-tabs__panel'); var tab_links = $('.responsive-tabs .responsive-tabs__list__item');
		  tab_group.hide().filter(':first').show();
		  $('.responsive-tabs .responsive-tabs__list__item:first').addClass('responsive-tabs__list__item--active');
		  tab_links.click(function(){
			  var tab_id = $(this).attr('data-id');
				  tab_group.hide();
				  tab_links.removeClass('responsive-tabs__list__item--active');
				  $(this).addClass('responsive-tabs__list__item--active');
				  $(tab_id).show();
			  return false;	
	})
	
	// more link
	$('#link_to_more').click(function(){
		$('#more_info_tab_more_info').trigger('click');
		 page.animate({ scrollTop: $('#more_info_tabs').offset().top + 20 }, 800);
	})
	

  $('#other_reviews a').click(function(){
	  $('#other_reviews_hidden').slideDown();
	  $('#other_reviews').hide()
  })
  $('#addnew_review').click(function(){
	  $('#sendComment').slideDown();
	  $('#addnew_review').hide();
  })
  
  $('#sendComment .align_right').click(function(){
  	$('#sendComment').slideUp();
	 $('#addnew_review').show();
  })
 

  $(window).bind('hashchange', function () {
	  var page = $('body,html');
	  var hash = window.location.hash;
	  var topPos = 0;
  
	  if (hash == "#review_form") {
		   page.animate({ scrollTop: $('.tabs-wrap').offset().top - 20 }, 800);
			tab_group.hide();
			$('#sendComment, #review_form').show();
			tab_links.removeClass('responsive-tabs__list__item--active');
			$('.comment-tab').addClass('responsive-tabs__list__item--active');
			  $('#addnew_review').hide()
			  $("#sendComment").show()
	  }
  });
  $(window).trigger("hashchange");  

})